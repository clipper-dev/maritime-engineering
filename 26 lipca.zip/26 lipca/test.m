figure
hold on
for kk=1:6
    plot( dane_sym(kk, 3), dane_sym(kk,2),'x')
    pause
end
